import { Card} from "./components/Card"
import { Feedback } from "./components/Feedback";
import { Header } from "./components/Header";


export default function  App() {

  return (
      <div>
        <Header/>
          <Card/>
        <Feedback/>
      </div>
  );
}

 
