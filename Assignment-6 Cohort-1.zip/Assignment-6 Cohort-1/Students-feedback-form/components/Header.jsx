function Handler(){
   return(
        <div className="head">
            <h2 className="head-text">Student Feedback Form </h2>
            <hr/>
        </div>
   )
}


export function Header(){
    return(
        <div>
            <Handler/>
        </div>    
    )
}